/* RacingGrip — comportamiento de la tienda */
(() => {
  const fmt = (cents, cur) => {
    try { return new Intl.NumberFormat(document.documentElement.lang || 'es', { style: 'currency', currency: cur || 'EUR' }).format(cents / 100); }
    catch (e) { return (cents / 100).toFixed(2) + ' €'; }
  };

  // Galería de producto
  document.querySelectorAll('[data-rg-gallery]').forEach(g => {
    const main = g.querySelector('#rg-main-img');
    if (!main) return;
    const thumbs = [...g.querySelectorAll('[data-rg-thumb]')];
    const count = g.querySelector('[data-rg-count]');
    let i = 0;
    const show = n => {
      if (!thumbs.length) return;
      i = (n + thumbs.length) % thumbs.length;
      const t = thumbs[i];
      main.src = t.dataset.src; main.srcset = t.dataset.srcset || ''; main.alt = t.dataset.alt || '';
      thumbs.forEach((b, k) => b.setAttribute('aria-current', k === i));
      if (count) count.textContent = (i + 1) + ' / ' + thumbs.length;
      t.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    };
    thumbs.forEach((b, k) => b.addEventListener('click', () => show(k)));
    g.querySelector('[data-rg-prev]')?.addEventListener('click', () => show(i - 1));
    g.querySelector('[data-rg-next]')?.addEventListener('click', () => show(i + 1));
    g.rgShowMedia = id => { const k = thumbs.findIndex(b => b.dataset.mediaId === String(id)); if (k >= 0) show(k); };
  });

  // Selector de variantes
  document.querySelectorAll('[data-rg-product]').forEach(root => {
    const data = JSON.parse(root.querySelector('[data-rg-variants]').textContent);
    const cur = root.dataset.currency;
    const form = root.querySelector('form[action*="/cart/add"]');
    const idInput = form.querySelector('input[name="id"]');
    const priceNow = root.querySelector('[data-rg-price]');
    const priceWas = root.querySelector('[data-rg-compare]');
    const sku = root.querySelector('[data-rg-sku]');
    const addBtn = root.querySelector('[data-rg-add]');
    const gallery = document.querySelector('[data-rg-gallery]');
    const fieldsets = [...root.querySelectorAll('[data-rg-option]')];

    const selected = () => fieldsets.map(fs => fs.querySelector('input:checked')?.value);
    const update = () => {
      const opts = selected();
      fieldsets.forEach((fs, k) => { const lab = fs.querySelector('[data-rg-selected]'); if (lab) lab.textContent = opts[k] || ''; });
      const v = data.find(v => v.options.every((o, k) => o === opts[k]));
      if (!v) { addBtn.disabled = true; addBtn.textContent = 'No disponible'; return; }
      idInput.value = v.id;
      priceNow.textContent = fmt(v.price, cur);
      if (priceWas) { priceWas.hidden = !(v.compare_at_price > v.price); priceWas.textContent = v.compare_at_price ? fmt(v.compare_at_price, cur) : ''; }
      if (sku) sku.textContent = v.sku ? 'Ref. ' + v.sku : '';
      addBtn.disabled = !v.available;
      addBtn.textContent = v.available ? addBtn.dataset.label : 'Agotado';
      if (v.featured_media && gallery?.rgShowMedia) gallery.rgShowMedia(v.featured_media.id);
      const url = new URL(location.href); url.searchParams.set('variant', v.id); history.replaceState({}, '', url);
    };
    fieldsets.forEach(fs => fs.addEventListener('change', update));

    // Cantidad
    const q = root.querySelector('[data-rg-qty] input');
    root.querySelectorAll('[data-rg-step]').forEach(b => b.addEventListener('click', () => {
      q.value = Math.max(1, (parseInt(q.value, 10) || 1) + parseInt(b.dataset.rgStep, 10));
    }));
  });

  // Carrito: enviar al cambiar cantidad
  document.querySelectorAll('[data-rg-cart-qty]').forEach(inp => inp.addEventListener('change', () => inp.form.requestSubmit ? inp.form.requestSubmit() : inp.form.submit()));

  // Ordenar colección
  document.querySelectorAll('[data-rg-sort]').forEach(sel => sel.addEventListener('change', () => {
    const url = new URL(location.href); url.searchParams.set('sort_by', sel.value); url.searchParams.delete('page'); location.href = url;
  }));

  // Cerrar desplegables al hacer clic fuera
  document.addEventListener('click', e => {
    document.querySelectorAll('.rg-nav details[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); });
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    document.querySelectorAll('.rg-nav details[open], .rg-drawer[open]').forEach(d => d.removeAttribute('open'));
  });
})();
